# KastDLC (Fabric, Minecraft 26.2)

Визуальный клиент: Click GUI на пять панелей (Combat, Movement, Visuals, Player, Miscellaneous),
поиск, бинды, конфиги, свой скруглённый рендер, анимации.

## Сборка

Нужны **JDK 25** и интернет (Gradle скачает Minecraft и Fabric).

```
./gradlew build          # Windows: gradlew.bat build
./gradlew runClient      # запуск игры из проекта
```

Готовый мод: `build/libs/kastdlc-1.0.0.jar`. Кладётся в `mods/` вместе с **Fabric API 0.160.0+26.2**
(Fabric Loader 0.19.5+).

## Управление

| Действие | Как |
|---|---|
| Открыть/закрыть GUI | Right Shift (Esc тоже закрывает) |
| Включить модуль | ЛКМ по строке |
| Настройки | ПКМ по строке; повторный ПКМ сворачивает. Если настроек нет, покажет подсказку |
| Забиндить | СКМ по строке или строка Bind в настройках. Backspace снимает, Esc отменяет |
| Двигать панель | зажать заголовок панели и тянуть |
| Прокрутка | колесо над нужной панелью (у каждой своя) |
| Поиск | просто печатай в строке внизу; Enter прыгает к первому найденному; крестик очищает |
| Конфиги | кнопка Configs рядом с поиском: имя, Save, Load, Del |

Конфиги: `.minecraft/config/kastdlc/*.json`. `default.json` сохраняется при закрытии GUI и
загружается при старте.

## Модули

- Visuals: Watermark, ArrayList, Radar, Waves, ESP, Tracers, Fullbright
- Player: Info, Keystrokes
- Miscellaneous: Interface (цвет акцента и стиль Static / Gradient / Rainbow)
- Combat и Movement пока пустые: фиктивных модулей нет. Новый модуль = класс с `Category.COMBAT`
  (или другой) + одна строка в `ModuleManager.init()`, и он сам появится в GUI со всеми настройками.

## Структура GUI

- `gui/ClickGuiScreen` — экран, ввод, поиск, окно конфигов
- `gui/CategoryPanel` — панель категории со своим скроллом и scissor
- `gui/ModuleEntry` — строка модуля, анимации наведения и включения
- `gui/ModuleSettingsPanel` — настройки модуля (Boolean, Number, Mode-выпадашка, Color, Bind)
- `render/Gfx` — сглаженные скруглённые фигуры в физических пикселях, тени, текст
- `render/GuiRenderer`, `Tween`, `Ease`, `AnimationController` — виджеты и анимации по delta time

## Если после обновления Minecraft не собирается

Версионно-зависимое собрано в `render/Gfx.java`, `util/Compat.java`, `KastClient.java` и
сигнатурах методов `ClickGuiScreen`. Для 26.2: `GuiGraphicsExtractor`, `extractRenderState`,
`mc.gui.setScreen(...)`, `mc.gui.screen()`, `mc.gui.hud.isHidden()`.

## Важно

Многие серверы банят ESP, Tracers, Fullbright и подобное. Пользуйся на своих серверах или в одиночке.
